﻿namespace AndroidX.Core.Graphics
{
    internal class Resource
    {
    }
}